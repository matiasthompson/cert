<?php

    include('./setup/config.php');
    include('./setup/arrays.php');

    $qmc = isset($_GET['qmc']) ? true : false;
    $err = isset($_GET['err']) ? $_GET['err'] : null;
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Sense Login</title>
       
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="shortcut icon" href="favicon.ico">
        
        <!-- Cargamos jquery-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
        <!-- Cargamos bootstrap-->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- Cargamos pNotify -->
        <script src="./styles/pnotify/dist/pnotify.js"></script>
        <script src="./styles/pnotify/dist/pnotify.buttons.js"></script>
        <script src="./styles/pnotify/dist/pnotify.confirm.js"></script>
        <script src="./styles/pnotify/dist/pnotify.animate.js"></script>
        
        <!-- Bootstrap -->
        <link href="./styles/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link href="./styles/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- Cargamos pNotify -->
        <link href="./styles/pnotify/dist/pnotify.css"rel="stylesheet"/>
        <link href="./styles/pnotify/dist/pnotify.buttons.css" rel="stylesheet"/>
        <link href="./styles/pnotify/dist/pnotify.animate.css" rel="stylesheet"/>
        <link href="./styles/pnotify/dist/pnotify.brighttheme.css" rel="stylesheet"/>
        <!-- Custom Theme Style -->
        <link href="./styles/custom.css" rel="stylesheet">
        
    </head>    
    <body class="login">
        <div>
            <a class="hiddenanchor" id="signup"></a>
            <a class="hiddenanchor" id="signin"></a>

            <div class="login_wrapper">
                <div class="animate form login_form">        
                    <section class="login_content">
                        <h1>Ingreso a Sense</h1>
                        <?php
                            if(!$qmc){
                        ?>
                        <form id="form" action="./actions/LDAP_Auth.php" method="POST" enctype="multipart/form-data" class="container_fluid">
                            <div id="userInput">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                                        <select class="form-control" id="ud" name="ud" required>
                                            <?php
                                         
                                                foreach($countries as $row){
                                                    echo '<option value="' . $row . '">' . $row . '</option>';
                                                }    
                                            
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
                                        <input type="text" class="form-control" placeholder="Usuario" id="user" name="user" required/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <input type="password" class="form-control" placeholder="Contraseña" id="pass" name="pass" required/-->
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <button type="submit" class="btn btn-success submit btn-block">INGRESAR <i class="fa fa-sign-in"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <?php } ?>
                        <?php
                            if($qmc){
                        ?>
                            <div id="redirectButtons" class="row">
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <a href="./Actions/SENSE_Ticket.php?sec=hub" class="btn btn-success submit btn-block">HUB <i class="fa fa-dashboard"></i></a>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <a href="./Actions/SENSE_Ticket.php?sec=qmc" class="btn btn-success submit btn-block">QMC <i class="fa fa-dashboard"></i></a>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                                    <a href="./Actions/SENSE_Ticket2.php?sec=qmc" class="btn btn-success submit btn-block">Cerrar<i class="fa fa-dashboard"></i></a>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="clearfix"></div>
                        <div class="separator">
                            <p class="change_link">* Para ingresar a QlikSense es necesario hacerlo con las credenciales de infra.d</p>
                            <div class="clearfix"></div>
                            <div>
                                <h2><img src="./img/bi_blanco.png" alt=""  style="margin-right: 15px;"><img src="./img/despegar_blanco.png" alt=""></h2>
                                <p>©2017 Despegar BI - Equipo Qlik Sense</p>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
        <div id="alert">
        </div>
        <?php
            if( $err != null && $err >= 0 && $err < 5 ){
        ?>
            
            <script>
                
                $(function(){
                    var stack_bar_bottom = {"dir1": "down", "dir2": "right", "firstpos1": "0px", "firstpos2": "0px"};

                    var options = {
                        title: '<?php echo $notify[$err][0]; ?>',
                        text: '<?php echo $notify[$err][1]; ?>',
                        cornerclass: "",
                        width: "100%",
                        addclass: "stack-bottomleft",
                        stack: stack_bar_bottom,
                        delay: 4000,
                        styling: 'fontawesome'
                        <?php
                            if($err == 3){
                        ?>
                        ,confirm: {
                            confirm: true,
                            buttons: [{
                                text: 'Enviar',
                                addClass: 'btn-success',
                                click: function(){
                                    $window.open('https://mail.google.com/mail/u/0/?view=cm&fs=1&to=bi@despegar.com&su=Solicitud%20Usuario%20Qlik%20Sense&body=Buenas,%20solicito%20por%20favor%20el%20acceso%20a%20QLik%20Sense.&tf=1', '_blank');
                                    PNotify.removeAll();
                                }
                            }, {
                                text: 'Cancelar',
                                addClass: 'btn-danger',
                                click: function(){
                                    PNotify.removeAll();
                                }
                            }]
                        }
                        <?php } ?>
                    };

                    var show_stack_bar_bottom = function(type, options) {

                        var opts = options;

                        switch (type) {
                        case 0:
                            opts.type = "warning";
                            break;
                        case 1:
                            opts.type = "error";
                            break;
                        case 2:
                            opts.type = "error";
                            break;
                        case 3:
                            opts.type = "warning";
                            break;
                        case 4:
                            opts.type = "success";
                            break;
                        }
                        new PNotify(opts);
                    }

                    show_stack_bar_bottom(<?php echo $err; ?>, options);
                });
                
            </script>
        
        <?php } ?>
    </body>
</html>