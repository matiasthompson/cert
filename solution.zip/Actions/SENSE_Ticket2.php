<?php

    include('../setup/config.php');
    include('../setup/arrays.php');

    $ud   = isset($_SESSION['ud'])   && !(empty($_SESSION['ud']))   ? $_SESSION['ud']   : null;
    $user = isset($_SESSION['user']) && !(empty($_SESSION['user'])) ? $_SESSION['user'] : null;
    $sec  = isset($_GET['sec'])      && !(empty($_GET['sec']))      ? $_GET['sec']     : $_SESSION['sec'];

    $url = $reqTicket['requestUrl'] . $reqTicket['secret']; 

    $reqFields = array(
        'UserDirectory' => $ud,
        'UserId'        => $user,
        'Attributes'    => array(),
    );

    $options = array(
        CURLOPT_URL            => $url,
        CURLOPT_SSLCERT        => $certs['cert'],
        CURLOPT_SSLCERTPASSWD  => $certs['pass'],
        CURLOPT_SSLKEY         => $certs['key'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER     => array('X-qlik-xrfkey: ' . $reqTicket['secret'], 'Content-Type: application/json'),
        CURLOPT_POSTFIELDS     => json_encode($reqFields)
    );

    if($ud && $user && $sec){
        $ticket = reqTicket($options);
        session_destroy();
        echo $reqTicket['redirectUrl'] . $reqTicket[$sec] . $ticket;
        //header("location: " . $reqTicket['redirectUrl'] . $reqTicket[$sec] . $ticket);
        //die();
    }
    
    //#########################################################################################//
    //###################################                   ###################################//
    //###################################       TICKET      ###################################//
    //###################################                   ###################################//
    //#########################################################################################//

    function reqTicket($options){
        $request = curl_init();
        curl_setopt_array($request, $options);
        $response = curl_exec($request);

        if (!$response){
            return null;
        }else{
            $ticket = json_decode($response, true);
            return $ticket["Ticket"];
        }
    }

?>