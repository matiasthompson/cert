<?php
    
    include('../setup/config.php');
    include('../setup/arrays.php');

    if( isset($_POST['ud']) && !(empty($_POST['ud'])) ){    
        $_SESSION['ud'] = $_POST['ud'];
        $ud = $_SESSION['ud'];
    }
    
    if( isset($_POST['user']) && !(empty($_POST['user'])) ){    
        $_SESSION['user'] = $_POST['user'];
        $user = $_SESSION['user'];
    }
    
    $pass = isset($_POST['pass']) && !(empty($_POST['pass'])) ? $_POST['pass'] : null;
    
    if($ud && $user && $pass){
        echo 'País, Usuario y Contraseña ingresados. <br />';
        
        $userPrincipalName = "$user@$ud.infra.d";
        $filter = "(samaccountname=$user)";
        $attrs = array("memberOf");
    
        $ds = @ldap_connect($ldap['host'], $ldap['port']);
        
        if( $ds ) {
            echo 'Acceso a LDAP. <br />';
            
            ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
            ldap_set_option($ds, LDAP_OPT_REFERRALS, 0);
        
            $ldapbind = @ldap_bind($ds, $userPrincipalName, $pass);
            
            if( getErr($ds) == -1 ) {
                echo 'Imposible conectar con el Servidor LDAP. <br />';

                header("location: ../index.php?err=1");
                die();    
            } else if( getErr($ds) == 49 ) {
                echo 'Imposible conectar con el Servidor LDAP. <br />';
            
                header("location: ../index.php?err=2");
                die();    
            } else {
                echo "Credenciales válidas. <br />";
            
                $userdn = getDN($ds, $user, $ldap['basedn']);
                echo $userdn . "<br />";
            
                if (checkGroupEx($ds, $userdn, $ldap['accessGroup'])) {
                    echo "Autorización correcta. <br />";

                    if (checkGroupEx($ds, $userdn, $ldap['adminGroup'])) {
                        echo "Autorizado como Administrador <br />";
                        
                        header("location: ../index.php?qmc&err=4");
                        die();
                    } else {
                        echo "No autorizado como Administrador <br />";
                        
                        $_SESSION['sec'] = hub;
                        header("location: ./SENSE_Ticket.php");
                        die();
                    }
                } else {
                    echo 'Aurización fallida. <br />';
                    
                    header("location: ../index.php?err=3");
                    die();
                }
                
                ldap_unbind($ds); 
            }
        }
    } else {
        echo 'Sin acceso a LDAP. <br />';
        
        header("location: ../index.php?err=0");
        die();
    }

    //#########################################################################################//
    //###################################                   ###################################//
    //###################################        LDAP       ###################################//
    //###################################                   ###################################//
    //#########################################################################################//
    
    function getErr($ds){
        $err = ldap_errno($ds);
        return $err;
    }

    function getDN($ds, $user, $basedn) {
        $attributes = array('dn');
        $result = ldap_search($ds, $basedn, "(samaccountname=$user)", $attributes);
        if ($result === FALSE) { return ''; }
        $entries = ldap_get_entries($ds, $result);
        if ($entries['count']>0) { return $entries[0]['dn']; }
        else { return ''; };
    }

    function getCNofDN($userdn) {
        $return=preg_match('/[^cn=]([^,]*)/i',$userdn,$userdn);
        print_r($return);
        return($userdn[0]);
    }

    function checkGroupEx($ds, $userdn, $group) {
        $attributes = array('memberof');
        $result = ldap_read($ds, $userdn, '(objectclass=*)', $attributes);
        if ($result === FALSE) { return FALSE; };
        $entries = ldap_get_entries($ds, $result);
        if ($entries['count'] <= 0) { return FALSE; };
        if (empty($entries[0]['memberof'])) { return FALSE; } else {
            for ($i = 0; $i < $entries[0]['memberof']['count']; $i++) {
                if ($entries[0]['memberof'][$i] == $group) { return TRUE; }
                elseif (checkGroupEx($ds, $entries[0]['memberof'][$i], $group)) { return TRUE; };
            };
        };
        return FALSE;
    }

?>